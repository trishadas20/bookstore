<template>
  <div>
     <h1>Hello from home component</h1>
     <h2>{{data}}</h2>
  </div>
 
</template>

<script>
export default {
  name: 'HomePage',   // FIXED
  props:{
    data:String
  }
};
</script>
